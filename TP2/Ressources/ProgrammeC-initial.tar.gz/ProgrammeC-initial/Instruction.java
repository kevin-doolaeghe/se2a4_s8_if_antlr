public abstract class Instruction {
	abstract int execute(Env env);
}



